const products = [
  {
    id: 1,
    name: "Classic White Shirt",
    price: "₹999",
    image: "images/product1.jpg",
  },
  {
    id: 2,
    name: "Denim Jacket",
    price: "₹1800",
    image: "images/product2.jpg",
  },
  {
    id: 3,
    name: "Leather Boots",
    price: "₹2600",
    image: "images/product3.jpg",
  },
  {
    id: 4,
    name: "Running Sneakers",
    price: "₹3999",
    image: "images/product4.jpg",
  },
  {
    id: 5,
    name: "Casual Hoodie",
    price: "₹2000",
    image: "images/product5.jpg",
  },
  {
    id: 6,
    name: "Slim Fit Jeans",
    price: "₹1499",
    image: "images/product6.jpg",
  },
];

const productGrid = document.getElementById("productGrid");

products.forEach((product) => {
  const card = document.createElement("div");
  card.className = "product-card";
  card.innerHTML = `
    <img src="${product.image}" alt="${product.name}" />
    <h3>${product.name}</h3>
    <p>${product.price}</p>
    <button>Add to Cart</button>
  `;
  productGrid.appendChild(card);
});
