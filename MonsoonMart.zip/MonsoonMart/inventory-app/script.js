const form = document.getElementById("inventoryForm");
const messageDiv = document.getElementById("message");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const data = {
    productName: document.getElementById("productName").value,
    sku: document.getElementById("sku").value,
    brand: document.getElementById("brand").value,
    rate: parseFloat(document.getElementById("rate").value),
    quantity: parseInt(document.getElementById("quantity").value),
  };

  fetch("http://localhost:3000/inventory", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to update inventory");
      }
      return response.json();
    })
    .then((result) => {
      messageDiv.textContent = "Inventory updated successfully";
      messageDiv.style.color = "green";
      form.reset();
    })
    .catch((error) => {
      messageDiv.textContent = "Error: " + error.message;
      messageDiv.style.color = "red";
    });
});
